Functional Programming Principles in Scala
==========================================

I took the online Functional Programming Principles in Scala course (https://class.coursera.org/progfun-2012-001) taught by Martin Odersky from Sep - Dec 2012.

This repository contains my solutions to all the programming exercises.
